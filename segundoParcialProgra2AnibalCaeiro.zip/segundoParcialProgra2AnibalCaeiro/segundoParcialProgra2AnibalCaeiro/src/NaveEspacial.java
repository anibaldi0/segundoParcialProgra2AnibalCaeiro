import java.io.Serializable;

public class NaveEspacial implements CSVSerializable, Comparable<NaveEspacial>, Serializable {
    private static final long serialVersionUID = 1L;

    private int idNombre;
    private String nombre;
    private Categoria categoria;
    private int capacidadTripulacion;

    public NaveEspacial(int idNombre, String nombre, Categoria categoria, int capacidadTripulacion) {
        this.idNombre = idNombre;
        this.nombre = nombre;
        this.categoria = categoria;
        this.capacidadTripulacion = capacidadTripulacion;
    }

    public int getIdNombre() {
        return idNombre;
    }

    public String getNombre() {
        return nombre;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public int getCapacidadTripulacion() {
        return capacidadTripulacion;
    }

    @Override
    public int compareTo(NaveEspacial otra) {
        return this.nombre.compareTo(otra.nombre);
    }

    @Override
    public String toString() {
        return "NaveEspacial{" +
               "idNombre=" + idNombre +
               ", nombre='" + nombre + '\'' +
               ", categoria=" + categoria +
               ", capacidadTripulacion=" + capacidadTripulacion +
               '}';
    }

    @Override
    public String toCSV() {
        return idNombre + "," + nombre + "," + categoria + "," + capacidadTripulacion;
    }

    @Override
    public void fromCSV(String csvLine) {
        String[] datos = csvLine.split(",");
        this.idNombre = Integer.parseInt(datos[0]);
        this.nombre = datos[1];
        this.categoria = Categoria.valueOf(datos[2]);
        this.capacidadTripulacion = Integer.parseInt(datos[3]);
    }
}
