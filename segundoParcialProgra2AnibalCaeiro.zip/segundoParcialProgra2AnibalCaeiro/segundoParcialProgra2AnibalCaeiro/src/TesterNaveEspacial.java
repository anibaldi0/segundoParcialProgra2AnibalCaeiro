import java.io.IOException;

public class TesterNaveEspacial {

    public static void main(String[] args) {
        try {
            Inventario<NaveEspacial> inventarioNaves = new Inventario<>();

            inventarioNaves.agregar(new NaveEspacial(1, "USS Enterprise", Categoria.EXPLORACION, 500));
            inventarioNaves.agregar(new NaveEspacial(2, "Millennium Falcon", Categoria.CARGA, 6));
            inventarioNaves.agregar(new NaveEspacial(3, "TIE Fighter", Categoria.MILITAR, 1));
            inventarioNaves.agregar(new NaveEspacial(4, "X-Wing", Categoria.MILITAR, 1));
            inventarioNaves.agregar(new NaveEspacial(5, "Discovery One", Categoria.EXPLORACION, 3));
            inventarioNaves.agregar(new NaveEspacial(15, "Serenity", Categoria.CARGA, 10));

            System.out.println("Inventario de naves espaciales:");
            inventarioNaves.listar().forEach(System.out::println);

            inventarioNaves.ordenarPorNombre();
            System.out.println("\nInventario ordenado por nombre:");
            inventarioNaves.listar().forEach(System.out::println);

            inventarioNaves.ordenarPorCapacidad();
            System.out.println("\nInventario ordenado por capacidad de tripulacion:");
            inventarioNaves.listar().forEach(System.out::println);

            System.out.println("\nNaves de la categoria EXPLORACION:");
            inventarioNaves.filtrarPorCategoria(Categoria.EXPLORACION)
                    .forEach(System.out::println);

            System.out.println("\nNaves transformadas (capacidad reducida a la mitad):");
            var navesTransformadas = inventarioNaves.transformarNaves();
            navesTransformadas.forEach(System.out::println);

            inventarioNaves.guardarConConfirmacion("naves.csv", "naves.bin");

            Inventario<NaveEspacial> inventarioCargado = new Inventario<>();
            System.out.println("\nNaves cargadas desde archivo BIN:");
            inventarioCargado.cargarDesdeArchivo("naves.bin");
            inventarioCargado.listar().forEach(System.out::println);

            inventarioCargado.cargarDesdeCSV("naves.csv", linea -> {
                NaveEspacial nave = new NaveEspacial(0, "", Categoria.EXPLORACION, 0);
                nave.fromCSV(linea);
                return nave;
            });
            System.out.println("\nNaves cargadas desde archivo CSV:");
            inventarioCargado.listar().forEach(System.out::println);

            // Ordenar por idNombre
            inventarioNaves.ordenarPorIdNombre();
            System.out.println("\nInventario ordenado por idNombre:");
            inventarioNaves.listar().forEach(System.out::println);

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
