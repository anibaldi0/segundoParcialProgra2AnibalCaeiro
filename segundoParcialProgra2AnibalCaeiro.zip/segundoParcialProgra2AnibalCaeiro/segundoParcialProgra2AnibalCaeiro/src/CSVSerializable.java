

public interface CSVSerializable {
    String toCSV();
    void fromCSV(String csvLine);
}
