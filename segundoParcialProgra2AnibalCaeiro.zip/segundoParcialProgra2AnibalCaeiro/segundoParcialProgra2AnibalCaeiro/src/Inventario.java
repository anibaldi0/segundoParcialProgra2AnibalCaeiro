import java.io.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class Inventario<T extends Comparable<T>> {
    private List<T> elementos;

    public Inventario() {
        this.elementos = new ArrayList<>();
    }

    public void agregar(T elemento) {
        elementos.add(elemento);
    }

    public void eliminar(T elemento) {
        elementos.remove(elemento);
    }

    public List<T> listar() {
        return new ArrayList<>(elementos);
    }

    public void ordenar() {
        Collections.sort(elementos);
    }

    public void ordenarPorNombre() {
        Collections.sort(elementos);
    }

    public void ordenarPorCapacidad() {
        elementos.sort(Comparator.comparingInt(nave -> ((NaveEspacial) nave).getCapacidadTripulacion()));
    }

    public void ordenarPorIdNombre() {
        elementos.sort(Comparator.comparingInt(nave -> ((NaveEspacial) nave).getIdNombre()));
    }

    public List<T> filtrar(Predicate<T> criterio) {
        List<T> resultado = new ArrayList<>();
        for (T elemento : elementos) {
            if (criterio.test(elemento)) {
                resultado.add(elemento);
            }
        }
        return resultado;
    }

    public List<T> filtrarPorCategoria(Categoria categoria) {
        return filtrar(nave -> ((NaveEspacial) nave).getCategoria() == categoria);
    }

    public <R> List<R> transformar(Function<T, R> transformador) {
        List<R> resultado = new ArrayList<>();
        for (T elemento : elementos) {
            resultado.add(transformador.apply(elemento));
        }
        return resultado;
    }

    public List<NaveEspacial> transformarNaves() {
        List<NaveEspacial> resultado = new ArrayList<>();
        for (T elemento : elementos) {
            NaveEspacial nave = (NaveEspacial) elemento;
            resultado.add(new NaveEspacial(
                nave.getIdNombre(),
                nave.getNombre(),
                nave.getCategoria(),
                nave.getCapacidadTripulacion() / 2
            ));
        }
        return resultado;
    }

    public void paraCadaElemento(Consumer<T> accion) {
        for (T elemento : elementos) {
            accion.accept(elemento);
        }
    }

    public void guardarConConfirmacion(String rutaArchivoCSV, String rutaArchivoBin) throws IOException {
        File archivoCSV = new File(rutaArchivoCSV);
        File archivoBin = new File(rutaArchivoBin);

        if (archivoCSV.exists() || archivoBin.exists()) {
            System.out.println("El archivo " + rutaArchivoCSV + " y/o " + rutaArchivoBin + " ya existen. Desea sobreescribirlos? (s/n)");
            Scanner scanner = new Scanner(System.in);
            String respuesta = scanner.nextLine();
            if (!respuesta.equalsIgnoreCase("s")) {
                System.out.println("Operacion cancelada. No se guardaron cambios.");
                return;
            }
        }

        guardarEnCSV(rutaArchivoCSV);
        guardarEnArchivo(rutaArchivoBin);
    }

    public void guardarEnArchivo(String rutaArchivo) throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(rutaArchivo))) {
            out.writeObject(elementos);
        }
        System.out.println("Archivo binario guardado exitosamente en " + rutaArchivo);
    }

    public void cargarDesdeArchivo(String rutaArchivo) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(rutaArchivo))) {
            this.elementos = (List<T>) in.readObject();
        }
    }

    public void guardarEnCSV(String rutaArchivo) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaArchivo))) {
            for (T elemento : elementos) {
                if (elemento instanceof CSVSerializable) {
                    writer.write(((CSVSerializable) elemento).toCSV());
                    writer.newLine();
                }
            }
        }
        System.out.println("Archivo CSV guardado exitosamente en " + rutaArchivo);
    }

    public void cargarDesdeCSV(String rutaArchivo, Function<String, T> fromCSV) throws IOException {
        elementos.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                agregar(fromCSV.apply(linea));
            }
        }
    }
}
