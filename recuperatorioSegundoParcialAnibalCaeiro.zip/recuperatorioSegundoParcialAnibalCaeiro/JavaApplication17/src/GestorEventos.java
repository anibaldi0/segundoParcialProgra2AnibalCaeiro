import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.Comparator;
import java.util.Scanner;

public class GestorEventos<T extends Evento> implements Gestionable<T>, Serializable {
    private static final long serialVersionUID = 1L;
    private List<T> eventos;

    public GestorEventos() {
        eventos = new ArrayList<>();
    }

    @Override
    public void agregar(T evento) {
        eventos.add(evento);
    }

    @Override
    public void eliminar(int id) {
        eventos.removeIf(e -> e.getId() == id);
    }

    @Override
    public void limpiar() {
        eventos.clear();
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        return eventos.stream().filter(criterio).toList();
    }

    @Override
    public void ordenar(Comparator<T> criterio) {
        eventos.sort(criterio);
    }

    @Override
    public void mostrarTodos() {
        eventos.forEach(System.out::println);
    }

    @Override
    public void guardarEnCSV(String ruta) throws IOException {
        System.out.println("Preparando para guardar en archivo CSV...");
        if (preguntarSobrescritura(ruta)) {
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
                if (!eventos.isEmpty() && eventos.get(0) instanceof EventoMusical) {
                    bw.write(EventoMusical.toHeaderCSV());
                    bw.newLine();
                }
                for (T evento : eventos) {
                    if (evento instanceof EventoMusical) {
                        bw.write(((EventoMusical) evento).toCSV());
                        bw.newLine();
                    }
                }
                System.out.println("Archivo CSV guardado en " + ruta);
            }
        } else {
            System.out.println("Guardado cancelado por el usuario.");
        }
    }

    @Override
    public void guardarEnBinario(String ruta) throws IOException {
        System.out.println("Guardando archivo binario sin confirmacion...");
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
            oos.writeObject(eventos);
            System.out.println("Archivo binario guardado en " + ruta);
        }
    }

    @Override
    public void cargarDesdeCSV(String ruta) throws IOException {
        File archivo = new File(ruta);
        if (!archivo.exists()) {
            System.out.println("El archivo " + ruta + " no existe. Creando uno vacio.");
            guardarEnCSV(ruta);
        } else {
            try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
                br.readLine(); // Saltar la cabecera
                String linea;
                while ((linea = br.readLine()) != null) {
                    if (EventoMusical.class.isAssignableFrom(eventos.get(0).getClass())) {
                        eventos.add((T) EventoMusical.fromCSV(linea));
                    }
                }
            }
        }
    }

    @Override
    public void cargarDesdeBinario(String ruta) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
            eventos = (List<T>) ois.readObject();
        }
    }

    private boolean preguntarSobrescritura(String ruta) {
        File archivo = new File(ruta);
        if (archivo.exists()) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("El archivo " + ruta + " ya existe. Desea sobrescribirlo? (si/no):");
            String respuesta = scanner.nextLine();
            return respuesta.equalsIgnoreCase("si");
        }
        return true;
    }
}
