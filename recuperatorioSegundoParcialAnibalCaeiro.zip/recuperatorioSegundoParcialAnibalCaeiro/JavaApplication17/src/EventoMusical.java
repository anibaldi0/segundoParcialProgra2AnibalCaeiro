import java.time.LocalDate;

public class EventoMusical extends Evento implements Comparable<EventoMusical> {
    private String artista;
    private GeneroMusical genero;

    public EventoMusical(int id, String nombre, LocalDate fecha, String artista, GeneroMusical genero) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.genero = genero;
    }

    public String getArtista() {
        return artista;
    }

    public GeneroMusical getGenero() {
        return genero;
    }

    public String toCSV() {
        return id + "," + nombre + "," + fecha + "," + artista + "," + genero;
    }

    public static String toHeaderCSV() {
        return "id,nombre,fecha,artista,genero";
    }

    public static EventoMusical fromCSV(String csv) {
        String[] datos = csv.split(",");
        return new EventoMusical(
                Integer.parseInt(datos[0]),
                datos[1],
                LocalDate.parse(datos[2]),
                datos[3],
                GeneroMusical.valueOf(datos[4])
        );
    }

    @Override
    public int compareTo(EventoMusical otro) {
        return this.fecha.compareTo(otro.fecha);
    }

    @Override
    public String toString() {
        return super.toString() +
                ", artista='" + artista + '\'' +
                ", genero=" + genero;
    }
}
