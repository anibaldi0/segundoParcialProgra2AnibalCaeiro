

public class AppConfig {
    public static final String PATH_SER = "data/eventos.ser";
    public static final String PATH_CSV = "data/eventos.csv";
}
