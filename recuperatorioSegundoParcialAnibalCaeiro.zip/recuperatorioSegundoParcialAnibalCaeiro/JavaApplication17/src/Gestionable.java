import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;

public interface Gestionable<T> {
    void agregar(T evento);
    void eliminar(int id);
    void limpiar();
    List<T> filtrar(Predicate<T> criterio);
    void ordenar(Comparator<T> criterio);
    void mostrarTodos();
    void guardarEnBinario(String ruta) throws IOException;
    void cargarDesdeBinario(String ruta) throws IOException, ClassNotFoundException;
    void guardarEnCSV(String ruta) throws IOException;
    void cargarDesdeCSV(String ruta) throws IOException;
}


